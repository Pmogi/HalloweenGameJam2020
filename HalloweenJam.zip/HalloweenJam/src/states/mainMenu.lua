local Suit = require("lib.suit")
local GameState = require("lib.gamestate")

local LivingRoom = require("src.states.livingRoom")


local MainMenu = {}

local mainMenu = Suit.new()

function MainMenu:draw()
    mainMenu:draw()
end

function MainMenu:update(dt)
    if mainMenu:Button("Start Game", 100, 100).hit then
        GameState.switch(LivingRoom)
    end
end

function MainMenu:enter()

end

return MainMenu