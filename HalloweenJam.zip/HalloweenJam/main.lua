-- Lib
GameState       = require("lib.gamestate")
local Timer     = require("lib.timer")

-- Module
local Assets = require("src/assets")

-- -- States
local Menu       = require("src.states.mainMenu")
LivingRoom = require("src.states.livingRoom")
local Bathroom   = require("src.states.bathroom")
Basement   = require("src.states.basement")
local Calender   = require("src.states.calendar")

local World    = require("src.systems.world")


-- Test Harness
 local TestInv = require("src.test.invTest")

function love.load()
    TestInv.test1()
    
    GameState.registerEvents{'draw', 'update', 'init', 'enter', 'exit'}
    GameState.switch(LivingRoom)
    love.graphics.setFont(Assets.getAsset("font"))
end

function love.update(dt)
    Timer.update(dt) -- update timer module
    World.update(dt)
end
